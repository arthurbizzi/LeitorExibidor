var structinnerclasses =
[
    [ "ic", "structinnerclasses_1_1ic.html", "structinnerclasses_1_1ic" ],
    [ "classes", "structinnerclasses.html#af477a52b13ebc22541570276df6669c9", null ],
    [ "number_of_classes", "structinnerclasses.html#aaa0bded35d181ef941c1d5dfbf4ba35e", null ]
];