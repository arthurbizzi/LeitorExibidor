var structexceptionsattribute =
[
    [ "exception_index_table", "structexceptionsattribute.html#a08990d1a2e2a8f502643971c8717f7a5", null ],
    [ "number_of_exceptions", "structexceptionsattribute.html#aebc87f5091eff4de6b60ee94f2f06725", null ]
];