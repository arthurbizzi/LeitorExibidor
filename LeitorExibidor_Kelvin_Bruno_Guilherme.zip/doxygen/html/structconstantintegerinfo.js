var structconstantintegerinfo =
[
    [ "bytes", "structconstantintegerinfo.html#a97a61703bfa9c32f2cfa2709825b67ee", null ],
    [ "tag", "structconstantintegerinfo.html#a17726ed17c64ec8550633ebf17fd1a98", null ]
];