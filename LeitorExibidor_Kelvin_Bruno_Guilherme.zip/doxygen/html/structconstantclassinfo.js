var structconstantclassinfo =
[
    [ "name_index", "structconstantclassinfo.html#ae939ac3ca00f5727beaa02d0e339183d", null ],
    [ "tag", "structconstantclassinfo.html#a17726ed17c64ec8550633ebf17fd1a98", null ]
];