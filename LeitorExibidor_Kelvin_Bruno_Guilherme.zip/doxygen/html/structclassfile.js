var structclassfile =
[
    [ "access_flags", "structclassfile.html#a4cc32d48303aeaaaaea05bf77abdec59", null ],
    [ "attributes", "structclassfile.html#aae221e548ab4ef529cd1a0f2fcdabb9b", null ],
    [ "attributes_count", "structclassfile.html#aa53122439ee827a418258d52c51368c6", null ],
    [ "constant_pool", "structclassfile.html#ace3229f6e4d460d20e72e493d180ecc5", null ],
    [ "constant_pool_count", "structclassfile.html#a0d64ff67928a39e52a75c972b5f5697a", null ],
    [ "fields", "structclassfile.html#ae01d16d1ab715a4f5dd1fe8254322594", null ],
    [ "fields_count", "structclassfile.html#a8bebe0bfa4e37dde1e67c6a72af398c0", null ],
    [ "interfaces", "structclassfile.html#a31608612612ea019eef47ae5d656dc23", null ],
    [ "interfaces_count", "structclassfile.html#a5d766202b705d1bdb025a0e7fff8953c", null ],
    [ "magic", "structclassfile.html#a9c187266c328a40ddc2dde8c8a230a65", null ],
    [ "major_version", "structclassfile.html#a5a3ef20c14bd517fca3fa5841846ab4b", null ],
    [ "methods", "structclassfile.html#af0fc99630af87d96f99637f77f6bb565", null ],
    [ "methods_count", "structclassfile.html#a8858a4e08f7cc000e0f62459722ecce8", null ],
    [ "minor_version", "structclassfile.html#ad0028839ce12090266cbdc5df1046062", null ],
    [ "super_class", "structclassfile.html#a85a7fa4c7fd5d455b77e525d952f440f", null ],
    [ "this_class", "structclassfile.html#afd1a9f5d893befc9ea66f915fd6fa039", null ]
];