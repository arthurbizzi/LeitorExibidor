var structfieldinfo =
[
    [ "access_flags", "structfieldinfo.html#a4cc32d48303aeaaaaea05bf77abdec59", null ],
    [ "attributes", "structfieldinfo.html#aae221e548ab4ef529cd1a0f2fcdabb9b", null ],
    [ "attributes_count", "structfieldinfo.html#aa53122439ee827a418258d52c51368c6", null ],
    [ "descriptor_index", "structfieldinfo.html#a3f13794b6c8b4ffc87b87a7c01a69060", null ],
    [ "name_index", "structfieldinfo.html#ae939ac3ca00f5727beaa02d0e339183d", null ]
];