var structconstantnameandtypeinfo =
[
    [ "descriptor_index", "structconstantnameandtypeinfo.html#a3f13794b6c8b4ffc87b87a7c01a69060", null ],
    [ "name_index", "structconstantnameandtypeinfo.html#ae939ac3ca00f5727beaa02d0e339183d", null ],
    [ "tag", "structconstantnameandtypeinfo.html#a17726ed17c64ec8550633ebf17fd1a98", null ]
];