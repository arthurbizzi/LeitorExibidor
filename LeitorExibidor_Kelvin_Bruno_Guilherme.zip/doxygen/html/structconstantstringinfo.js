var structconstantstringinfo =
[
    [ "string_index", "structconstantstringinfo.html#a983a5b138b680d917526211445dbcdbf", null ],
    [ "tag", "structconstantstringinfo.html#a17726ed17c64ec8550633ebf17fd1a98", null ]
];