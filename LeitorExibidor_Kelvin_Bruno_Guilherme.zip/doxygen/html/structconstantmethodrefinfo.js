var structconstantmethodrefinfo =
[
    [ "class_index", "structconstantmethodrefinfo.html#a6004155348b07eae6cb68d413191efe9", null ],
    [ "name_and_type_index", "structconstantmethodrefinfo.html#adec52fa6971122714e8d390dd4b38048", null ],
    [ "tag", "structconstantmethodrefinfo.html#a17726ed17c64ec8550633ebf17fd1a98", null ]
];