var carregamento_8h =
[
    [ "carrega_attribute", "carregamento_8h.html#ac970fbb71fd741678519f0ac8059e9db", null ],
    [ "carrega_attributes", "carregamento_8h.html#af6a83209af1d46f9d75995921812c6eb", null ],
    [ "carrega_constantpool", "carregamento_8h.html#a1fd850299e3c4dd6bfc3a10766a85c90", null ],
    [ "carrega_fields", "carregamento_8h.html#a464e5cd9e9b44e84dcb3f3a49b27171a", null ],
    [ "carrega_flagseclasses", "carregamento_8h.html#a75abfca307fb4620182377434d9cff77", null ],
    [ "carrega_header", "carregamento_8h.html#ab19ad8d9e54bb02ec85db39413288f0f", null ],
    [ "carrega_interfaces", "carregamento_8h.html#adf210e7667840be7aa19a244a3a54ec9", null ],
    [ "carrega_methods", "carregamento_8h.html#a16def4c916274a450c3cc1d66201d681", null ],
    [ "le_u1", "carregamento_8h.html#ac2fcefe15ef7a88eb265d6e3ff4ca7bd", null ],
    [ "le_u2", "carregamento_8h.html#aa3a0520a41a8ece2ff21f792cd2be414", null ],
    [ "le_u4", "carregamento_8h.html#a21ccfa8617a9ab70216c67062acce262", null ]
];