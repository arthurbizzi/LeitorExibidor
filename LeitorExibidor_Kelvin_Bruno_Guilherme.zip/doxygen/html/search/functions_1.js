var searchData=
[
  ['dereferencia',['dereferencia',['../imprime_8c.html#a8ba5d36cda32a068c0d91e36b92eea4a',1,'dereferencia(u2 index, ClassFile *classe):&#160;imprime.c'],['../imprime_8h.html#a5b79b24988b1c6e52f71392cd047addf',1,'dereferencia(u2 index, ClassFile *classe):&#160;imprime.c']]]
];
