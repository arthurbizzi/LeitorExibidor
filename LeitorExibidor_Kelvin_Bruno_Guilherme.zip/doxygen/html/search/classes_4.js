var searchData=
[
  ['fieldinfo',['fieldinfo',['../structfieldinfo.html',1,'']]]
];
