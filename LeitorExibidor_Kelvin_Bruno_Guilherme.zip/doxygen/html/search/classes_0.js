var searchData=
[
  ['attributeinfo',['attributeinfo',['../structattributeinfo.html',1,'']]]
];
