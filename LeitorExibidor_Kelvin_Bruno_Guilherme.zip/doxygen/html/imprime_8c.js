var imprime_8c =
[
    [ "carrega_instrucoes", "imprime_8c.html#ae4f8a5f85274165378f0fa9bad9d53ca", null ],
    [ "dereferencia", "imprime_8c.html#a8ba5d36cda32a068c0d91e36b92eea4a", null ],
    [ "imprime_attribute", "imprime_8c.html#afc1f9eb4377c66132b3e7cedf502e1d5", null ],
    [ "imprime_attribute_file", "imprime_8c.html#a36317b6299a703bba0a28f74f7054e4c", null ],
    [ "imprime_attributes", "imprime_8c.html#a15277fbfe7a7741905e84632c7f2e3d3", null ],
    [ "imprime_attributes_file", "imprime_8c.html#a99b207edc9463e99ee1607b0fc4c327e", null ],
    [ "imprime_constant_pool", "imprime_8c.html#a45cf25a94735345dcde1c7229a781d15", null ],
    [ "imprime_constant_pool_file", "imprime_8c.html#a1e7acc3d8f536eeaf0ae0a6cedf26da2", null ],
    [ "imprime_fields", "imprime_8c.html#af06ea41455bea7d452bedb59434c0dfb", null ],
    [ "imprime_fields_file", "imprime_8c.html#a824813174b977fa05c933e2df930c44b", null ],
    [ "imprime_general_information", "imprime_8c.html#ad6c3de4ab82963a7f909578021408af9", null ],
    [ "imprime_general_information_file", "imprime_8c.html#a90db8a67d48bb3b72f3d8991841e2aa4", null ],
    [ "imprime_methods", "imprime_8c.html#a106a7bd7db691aea74b8f1953c44be1a", null ],
    [ "imprime_methods_file", "imprime_8c.html#a31f73cbf6d289ff97f9a1408ce733f30", null ],
    [ "verifica_match", "imprime_8c.html#aac3451b338f67fcbc9f84d75563404c7", null ]
];