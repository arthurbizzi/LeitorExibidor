var structconstantdoubleinfo =
[
    [ "high_bytes", "structconstantdoubleinfo.html#ac9717d5a233a28a073c738d75f2585af", null ],
    [ "low_bytes", "structconstantdoubleinfo.html#aa98182719e334000a87d75af9d288ff7", null ],
    [ "tag", "structconstantdoubleinfo.html#a17726ed17c64ec8550633ebf17fd1a98", null ]
];