var structconstantutf8info =
[
    [ "bytes", "structconstantutf8info.html#ac6ab0ef16fce28e02466e662e10f4acc", null ],
    [ "length", "structconstantutf8info.html#ad01efb9db3818b64eae5965bf341710f", null ],
    [ "tag", "structconstantutf8info.html#a17726ed17c64ec8550633ebf17fd1a98", null ]
];