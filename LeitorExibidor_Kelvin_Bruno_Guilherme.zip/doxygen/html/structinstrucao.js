var structinstrucao =
[
    [ "mnemonico", "structinstrucao.html#a281cd7484b4da946c0057d0ed377966b", null ],
    [ "operandos", "structinstrucao.html#a80a4972b0a058fe850e8698b7264ee87", null ],
    [ "qtd_operandos", "structinstrucao.html#a03e5c09dbf8e8fe64eda327e4237fbd1", null ]
];